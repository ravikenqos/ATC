/* <![CDATA[ */
!(function($){
	
	"use strict";
        
    $('.ut-datetimepicker').each(function() {
        
        $(this).datetimepicker({
            weeks:true,
        });
        
    });
        
})(window.jQuery);
 /* ]]> */	