import React, { Component } from 'react';

class PageContainer extends Component {
    render(){
        return (<h1>PageContainer</h1>);
    }
}

export default PageContainer