import React, { Component } from 'react';

import './App.css';

import Main from "./main";


class App extends Component {
  render() {
    return (
      <Main/>
    );
  }
}

export default App;
